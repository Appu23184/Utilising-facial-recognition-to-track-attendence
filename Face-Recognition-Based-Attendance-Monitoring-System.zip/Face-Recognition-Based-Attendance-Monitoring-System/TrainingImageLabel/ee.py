import streamlit as st
import sqlite3
import hashlib

# Database connection and setup
def connect_db():
    conn = sqlite3.connect('voting_app.db')
    return conn

def create_tables():
    conn = connect_db()
    cursor = conn.cursor()
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT NOT NULL UNIQUE,
            password_hash TEXT NOT NULL
        )
    ''')
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS topics (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            title TEXT NOT NULL,
            description TEXT,
            creator_id INTEGER,
            status TEXT NOT NULL,
            FOREIGN KEY (creator_id) REFERENCES users(id)
        )
    ''')
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS options (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            topic_id INTEGER,
            option_text TEXT NOT NULL,
            FOREIGN KEY (topic_id) REFERENCES topics(id)
        )
    ''')
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS votes (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER,
            option_id INTEGER,
            FOREIGN KEY (user_id) REFERENCES users(id),
            FOREIGN KEY (option_id) REFERENCES options(id)
        )
    ''')
    conn.commit()
    conn.close()

create_tables()

# User authentication functions
def hash_password(password):
    return hashlib.sha256(password.encode()).hexdigest()

def register_user(username, password):
    conn = connect_db()
    cursor = conn.cursor()
    try:
        cursor.execute('INSERT INTO users (username, password_hash) VALUES (?, ?)', 
                       (username, hash_password(password)))
        conn.commit()
    except sqlite3.IntegrityError:
        st.error("Username already exists.")
    conn.close()

def authenticate_user(username, password):
    conn = connect_db()
    cursor = conn.cursor()
    cursor.execute('SELECT * FROM users WHERE username = ? AND password_hash = ?', 
                   (username, hash_password(password)))
    user = cursor.fetchone()
    conn.close()
    return user

# Voting logic functions
def create_topic(title, description, creator_id):
    conn = connect_db()
    cursor = conn.cursor()
    cursor.execute('INSERT INTO topics (title, description, creator_id, status) VALUES (?, ?, ?, ?)', 
                   (title, description, creator_id, 'open'))
    conn.commit()
    conn.close()

def get_topics():
    conn = connect_db()
    cursor = conn.cursor()
    cursor.execute('SELECT * FROM topics WHERE status = "open"')
    topics = cursor.fetchall()
    conn.close()
    return topics

def add_option(topic_id, option_text):
    conn = connect_db()
    cursor = conn.cursor()
    cursor.execute('INSERT INTO options (topic_id, option_text) VALUES (?, ?)', 
                   (topic_id, option_text))
    conn.commit()
    conn.close()

def vote(user_id, option_id):
    conn = connect_db()
    cursor = conn.cursor()
    cursor.execute('INSERT INTO votes (user_id, option_id) VALUES (?, ?)', 
                   (user_id, option_id))
    conn.commit()
    conn.close()

# Results functions
def get_results(topic_id):
    conn = connect_db()
    cursor = conn.cursor()
    cursor.execute(''' 
        SELECT option_text, COUNT(votes.option_id) as vote_count
        FROM options
        LEFT JOIN votes ON options.id = votes.option_id
        WHERE topic_id = ?
        GROUP BY option_id
    ''', (topic_id,))
    results = cursor.fetchall()
    conn.close()
    return results

# Streamlit application
st.title("Family Voting and Decision Making App")

# User Registration
st.subheader("Register")
username = st.text_input("Username")
password = st.text_input("Password", type='password')

if st.button("Register"):
    register_user(username, password)
    st.success("Registration successful!")

# User Login
st.subheader("Login")
username_login = st.text_input("Username (for login)")
password_login = st.text_input("Password (for login)", type='password')

if st.button("Login"):
    user = authenticate_user(username_login, password_login)
    if user:
        st.success("Login successful!")
        user_id = user[0]  # Get user ID for further actions

        # Create Topic
        st.subheader("Create a Voting Topic")
        topic_title = st.text_input("Topic Title")
        topic_description = st.text_area("Description")
        
        if st.button("Create Topic"):
            create_topic(topic_title, topic_description, user_id)
            st.success("Topic created successfully!")

        # Show Open Topics
        st.subheader("Open Topics")
        topics = get_topics()
        for topic in topics:
            st.write(f"{topic[1]}: {topic[2]}")
            options = st.text_input("Add Option")
            if st.button("Add Option"):
                add_option(topic[0], options)
                st.success("Option added successfully!")

            # Voting Section
            st.write("Vote for an option:")
            conn = connect_db()
            cursor = conn.cursor()
            cursor.execute('SELECT * FROM options WHERE topic_id = ?', (topic[0],))
            options = cursor.fetchall()
            conn.close()

            for option in options:
                if st.button(f"Vote for {option[1]}"):
                    vote(user_id, option[0])
                    st.success("Vote recorded!")

        # Display Results
        st.subheader("Voting Results")
        for topic in topics:
            results = get_results(topic[0])
            st.write(f"Results for *{topic[1]}*:")
            for result in results:
                st.write(f"{result[0]}: {result[1]} votes")
    
    else:
        st.error("Invalid username or password.")